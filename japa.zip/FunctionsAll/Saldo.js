
const { ButtonBuilder, PermissionFlagsBits, ChannelType, ModalBuilder, TextInputBuilder, EmbedBuilder, ActionRowBuilder, TextInputStyle, ComponentType, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, DiscordAPIError } = require('discord.js');
const { obterEmoji } = require('../Handler/EmojiFunctions');

const { General, PagamentosSaldos } = require('../databases');
const { QuickDB } = require("quick.db");
const db = new QuickDB({ filePath: "databases/database.sqlite"});
const mercadopago = require("mercadopago")
const { Discord, AttachmentBuilder } = require("discord.js")
const axios = require("axios")


async function AdicionarSaldo(client, interaction, user, qtd) {

    if (qtd <= 0) return interaction.reply({ content: `ERROR: Você não pode adicionar um VALOR NEGATIVO ou ZERO em seu saldo.` })

    if (General.get('ConfigGeral').SaldoConfig.ValorMinimo > qtd) return interaction.reply({ content: `ERROR: Está função foi definida para ter um VALOR MÍNIMO de ${General.get('ConfigGeral').SaldoConfig.ValorMinimo}`, ephemeral: true })

    await interaction.reply({ content: `${obterEmoji(10)} | Gerando pagamento...`, ephemeral: true})

    setTimeout(async () => {
        const bonus = General.get('ConfigGeral').SaldoConfig.Bonus
        var saldoComBonus = Number(qtd) + (Number(qtd) * Number(bonus) / 100);
        if (bonus == 0) saldoComBonus = 0

        var totalvalor = Number(qtd) + (qtd * bonus / 100)
        if (bonus == 0) totalvalor = Number(qtd)

        var tt = General.get('ConfigGeral')

        let forFormat = Date.now() + tt.MercadoPagoConfig.TimePagament * 60 * 1000

        let timestamp = Math.floor(forFormat / 1000)

        const embed = new EmbedBuilder()
            .setColor(General.get(`ConfigGeral.ColorEmbed`) == '#635b44' ? 'Random' : `${General.get(`ConfigGeral.ColorEmbed`)}`)
            .setTitle(`${interaction.guild.name} | **Sistema de pagamento**`)
            .setDescription(`\`\`\`Pague com pix Para receber seu Saldo.\`\`\`\n${obterEmoji(4)} **| Valor:**\n${"R$ " + Number(qtd).toFixed(2)}\n${obterEmoji(6)} | Bônus de depósito:\n${General.get('ConfigGeral').SaldoConfig.Bonus}% - ${"R$ " + Number(saldoComBonus).toFixed(2)}\n${obterEmoji(7)} | Pagamento expira em: \n<t:${timestamp}> (<t:${timestamp}:R>)`)
            .setFooter({ text: `Após efetuar o pagamento, o tempo do saldo chegar na sua conta é de no máximo 1 minuto!`, iconURL: `${client.user.displayAvatarURL()}` })

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId("pixcopiaecolasaldo")
                    .setLabel('Pix Copia e Cola')
                    .setEmoji(`1213543527196131388`)
                    .setStyle(1)
                    .setDisabled(false),
                new ButtonBuilder()
                    .setCustomId("qrcodesaldo")
                    .setLabel('Qr Code')
                    .setEmoji(`1238271183523156029`)
                    .setStyle(1)
                    .setDisabled(false),
                new ButtonBuilder()
                    .setCustomId("deletemessageal")
                    .setEmoji(`1041371454211633254`)
                    .setStyle(4)
                    .setDisabled(false),)

        await interaction.editReply({ embeds: [embed], components: [row], ephemeral: true, content: `` }).then(async msg => {
            generatePagament(interaction, Number(qtd), totalvalor)
            setTimeout(() => {
                return interaction.editReply({ content: `**${obterEmoji(7)} | O Tempo para fazer o pagamento acabou!**`, embeds: [], components: [], ephemeral: true }).catch(() => { return })
            }, 60000 * 5)
        })
    }, 1000);
}






function generatePagament(interaction, qtd, totalvalor) {
    var u = Number(qtd).toFixed(2)
    mercadopago.configurations.setAccessToken(General.get('ConfigGeral').MercadoPagoConfig.TokenAcessMP);
    var payment_data = {
        transaction_amount: Number(u),
        description: `Pagamento | ${interaction.user.username} | Adicionar Saldo`,
        payment_method_id: 'pix',
        payer: {
            email: 'japanstorepayments@gmail.com',
            first_name: 'Homero',
            last_name: 'Brum',
            identification: {
                type: 'CPF',
                number: '09111189770'
            }
        }

    };
    mercadopago.configurations.setAccessToken(General.get('ConfigGeral').MercadoPagoConfig.TokenAcessMP)
    mercadopago.payment.create(payment_data).then(function (data) {
        const pix = data.body.point_of_interaction.transaction_data.qr_code;
        const qr = data.body.point_of_interaction.transaction_data.qr_code_base64;
        var nn = db.table('pag')
       
        nn.set(interaction.user.id, {pix: pix, qr: qr})
        ChecarPagamento(data.body.id, interaction, Number(qtd).toFixed(2), Number(totalvalor).toFixed(2))
    })
}

async function getqrcode(interaction, user) {
    var nn = db.table('pag')
    var a = await nn.get(interaction.user.id)
 
    var qr1 = Buffer.from(a.qr, "base64");
    const attachment = new AttachmentBuilder(qr1, { name: 'payment.png' });

    interaction.reply({files: [attachment], ephemeral: true})
}

async function CopiaECola(interaction, user) {
    var nn = db.table('pag')
    var a = await nn.get(interaction.user.id)
    interaction.reply({content: a.pix, ephemeral: true})
}



function ChecarPagamento(id, interaction, price,price2) {
    var meuInterval = setInterval(async () => {
        var res = await axios.get(`https://api.mercadopago.com/v1/payments/${id}`, {
            headers: {
                Authorization: `Bearer ${General.get('ConfigGeral').MercadoPagoConfig.TokenAcessMP}`
            }
        })
        if (res.data.status == 'approved') { // approved ou approved
            var u = PagamentosSaldos.get(`${interaction.user.id}.SaldoAccount`)
            clearInterval(meuInterval);
            PagamentosSaldos.set(`${interaction.user.id}.SaldoAccount`, PagamentosSaldos.get(`${interaction.user.id}.SaldoAccount`) + Number(price2))
            PagamentosSaldos.push(`${interaction.user.id}.IDCompras`, { ID: id, Valor: Number(price2) })
            var h = Number(price2)


            try {
              const channela = await interaction.guild.channels.cache.get(General.get('ConfigGeral.ChannelsConfig.ChannelLogAdm'));


              
            } catch (error) {
                
            }
            


            interaction.editReply({
                content: `${obterEmoji(8)} | Pagamento aprovado, você tinha R$ ${Number(u).toFixed(2)}, foi adicionado R$ ${Number(h).toFixed(2)} e agora você está com R$ ${PagamentosSaldos.get(`${interaction.user.id}.SaldoAccount`).toFixed(2)}.\n${obterEmoji(9)} | Id do Pagamento: ${id}`, embeds: [], components: []
            })
        }
    }, 1000 * 5);
    setTimeout(async () => {
        if (meuInterval) {
            clearInterval(meuInterval);
            try {
                await interaction.editReply({ content: `**${obterEmoji(7)} | O Tempo para fazer o pagamento acabou!**`, embeds: [], components: [], ephemeral: true }).catch(() => { return })
            } catch (error) {

            }
        }
    }, 60000 * 5);
}

module.exports = {
    AdicionarSaldo,
    getqrcode,
    CopiaECola
};