const Discord = require("discord.js");
const utilities = require("../../Lib/utilities");
const { updateMessageConfig } = require("../../FunctionsAll/BotConfig");

module.exports = {
  name: "botconfig",
  description: "[🛠|💰 Vendas Moderação] Configuro o bot",
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction, message) => {
    await interaction.deferReply({ ephemeral: true });

    if (!utilities.getUserHasPermission(interaction.user.id)){
      return interaction.editReply({ content: `❌ | Você não possui permissão para usar esse comando.`, ephemeral: true })
  }
    updateMessageConfig(interaction, interaction.user.id, client)
  }
}